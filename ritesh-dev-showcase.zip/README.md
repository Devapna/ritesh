# Ritesh Dev — Portfolio Showcase

A responsive, single-file portfolio landing page for video editor, videographer, documentary filmmaker, and digital creator Ritesh Dev.

## Preview

Open `index.html` in a browser. The page has no build step, external libraries, or image dependencies.

## Publish

Upload `index.html` to any static site host. For a typical host that expects a folder, upload the contents of this folder with `index.html` at the root.

## Customize

Edit `index.html` to update the introduction, work cards, experience, skills, links, phone, or email. Colors, typography, spacing, and responsive styles are in the `<style>` block near the top. The mobile navigation is handled by a short inline script at the bottom.

The page uses CSS illustrations in place of project images. Replace the `.work-visual` contents with project images or video covers when those portfolio assets are ready.
